#define SECRET_SSID "replace here to your ssid name"
#define SECRET_PASS "replace here to your password of wifi"