/*
 * Experiment 7: Relay Control for Low-Voltage Loads
 * Function: Timed relay on/off control, driving 5V/12V fan or LED strip
 * Hardware: EP-0257 Shield + 1-Channel Relay Module + Low-Voltage Load
 */

#define RELAY_PIN 9

void setup() {
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);  // Initial state: OFF
  
  Serial.begin(115200);
  Serial.println("Experiment 7: Relay Control");
  Serial.println("Relay toggles every 3 seconds");
}

void loop() {
  Serial.println("Relay: ON (Energized)");
  digitalWrite(RELAY_PIN, HIGH);  // HIGH-level trigger mode
  delay(3000);
  
  Serial.println("Relay: OFF (De-energized)");
  digitalWrite(RELAY_PIN, LOW);
  delay(3000);
}
