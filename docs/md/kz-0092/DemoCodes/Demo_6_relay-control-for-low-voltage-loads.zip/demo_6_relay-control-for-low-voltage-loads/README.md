# 😀 Experiment 6: Relay Control for Low-Voltage Loads

## Principle
The relay module uses optocoupler isolation to achieve low-voltage control of high-voltage/high-current loads. Modules usually have HIGH-level trigger and LOW-level trigger modes, selectable via jumper cap.
⚠️ Safety Warning: This kit is only for controlling low-voltage loads (<< 30V DC). Controlling mains voltage (220V AC) requires professional knowledge and insulation protection — beginners are strictly prohibited from attempting this!

## Wiring Diagram
<pre>
UNO Q + EP-0257          Relay Module
├─ D9 (Blue) ───────────► IN (Signal Input)
├─ 5V (Red)  ───────────► VCC
└─ GND (Black)──────────► GND

Relay Output Terminals:
├─ COM (Common)─────────► Load one end + Power positive
├─ NO (Normally Open)───► Load other end (conducts when relay energized)
└─ NC (Normally Closed)─► (Not used in this experiment)
</pre>