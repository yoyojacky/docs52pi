# 😀  Experiment 8: Rotary Encoder

## Principle
Incremental encoders output two-phase quadrature pulses (A, B phases). Rotation direction is determined by phase difference. 
Includes push button function, outputs LOW when pressed.
