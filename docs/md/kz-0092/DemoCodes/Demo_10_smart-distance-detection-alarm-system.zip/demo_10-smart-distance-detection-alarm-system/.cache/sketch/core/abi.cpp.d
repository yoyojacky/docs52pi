/home/arduino/ArduinoApps/demo_11_smart-distance-detection-alarm-system/.cache/sketch/core/abi.cpp.o: \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/cores/arduino/abi.cpp \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/generated/zephyr/autoconf.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/zephyr/toolchain/zephyr_stdint.h
