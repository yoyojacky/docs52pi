#include <Arduino.h>
#line 1 "/home/arduino/ArduinoApps/demo_11_smart-distance-detection-alarm-system/sketch/sketch.ino"
/*
 * Comprehensive Project: Smart Distance Detection Alarm System
 * Hardware: UNO Q + EP-0257 + HC-SR04 + LCD1602 + MAX7219 + Buzzer
 * Function: Real-time distance measurement, LCD display, buzzer graded alarm, LED matrix direction indication
 * 
 * Modified: Use Bonezegei LCD1602 I2C library instead of LiquidCrystal_I2C
 */

#include <Wire.h>
#include <Bonezegei_LCD1602_I2C.h>
#include <MD_MAX72xx.h>
#include <SPI.h>

// Pin definitions
#define TRIG_PIN 2
#define ECHO_PIN 3
#define BUZZER_PIN 4
#define CS_PIN 10

// Object initialization
Bonezegei_LCD1602_I2C lcd(0x27);  // Only need I2C address, no cols/rows parameter
MD_MAX72XX mx = MD_MAX72XX(MD_MAX72XX::FC16_HW, CS_PIN, 1);

// Alarm thresholds (centimeters)
#define ALERT_CRITICAL 10   // Emergency
#define ALERT_WARNING  30   // Warning

// Arrow patterns (8x8)
const uint8_t arrowUp[8] = {
  0b00011000, 0b00111100, 0b01111110, 0b00011000,
  0b00011000, 0b00011000, 0b00011000, 0b00000000
};
const uint8_t arrowDown[8] = {
  0b00011000, 0b00011000, 0b00011000, 0b00011000,
  0b01111110, 0b00111100, 0b00011000, 0b00000000
};
const uint8_t alertIcon[8] = {
  0b00011000, 0b00111100, 0b01111110, 0b01111110,
  0b01111110, 0b00111100, 0b00011000, 0b00000000
};

#line 42 "/home/arduino/ArduinoApps/demo_11_smart-distance-detection-alarm-system/sketch/sketch.ino"
void setup();
#line 62 "/home/arduino/ArduinoApps/demo_11_smart-distance-detection-alarm-system/sketch/sketch.ino"
void loop();
#line 115 "/home/arduino/ArduinoApps/demo_11_smart-distance-detection-alarm-system/sketch/sketch.ino"
long measureDistance();
#line 130 "/home/arduino/ArduinoApps/demo_11_smart-distance-detection-alarm-system/sketch/sketch.ino"
void displayPattern(const uint8_t *pattern);
#line 137 "/home/arduino/ArduinoApps/demo_11_smart-distance-detection-alarm-system/sketch/sketch.ino"
void beep(int onTime, int offTime, int count);
#line 42 "/home/arduino/ArduinoApps/demo_11_smart-distance-detection-alarm-system/sketch/sketch.ino"
void setup() {
  // Initialize pins
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  
  // Initialize LCD (Bonezegei: begin() includes backlight on and Wire.begin())
  lcd.begin();
  lcd.setPosition(0, 0);
  lcd.print("Distance System");
  delay(1000);
  
  // Initialize MAX7219
  mx.begin();
  mx.control(MD_MAX72XX::INTENSITY, 8);
  
  Serial.begin(115200);
  Serial.println("System startup...");
}

void loop() {
  long distance = measureDistance();
  
  // LCD display
  lcd.clear();
  lcd.setPosition(0, 0);
  lcd.print("Dist: ");
  if (distance < 0) {
    lcd.print("Error");
  } else {
    // Bonezegei print() only supports const char* and char, convert number to string first
    char buf[16];
    sprintf(buf, "%ld cm", distance);
    lcd.print(buf);
  }
  
  // Status judgment and response
  if (distance < 0) {
    lcd.setPosition(0, 1);
    lcd.print("Sensor Error");
    displayPattern(alertIcon);
    beep(100, 100, 3);  // Rapid error indication
  }
  else if (distance < ALERT_CRITICAL) {
    // Critical state
    lcd.setPosition(0, 1);
    lcd.print("!! CRITICAL !!");
    displayPattern(alertIcon);
    beep(200, 100, 5);  // Rapid urgent alarm
  }
  else if (distance < ALERT_WARNING) {
    // Warning state
    lcd.setPosition(0, 1);
    lcd.print("! WARNING !");
    displayPattern(arrowUp);
    beep(500, 500, 2);  // Slow warning
  }
  else {
    // Safe state
    lcd.setPosition(0, 1);
    lcd.print("Safe Zone");
    displayPattern(arrowDown);
    noTone(BUZZER_PIN);
    digitalWrite(BUZZER_PIN, LOW);
  }
  
  Serial.print("Distance: "); Serial.print(distance);
  Serial.println(" cm");
  
  delay(300);
}

// Distance measurement function
long measureDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  
  long duration = pulseIn(ECHO_PIN, HIGH, 30000);
  if (duration == 0) return -1;
  
  long dist = duration * 0.017;
  return (dist > 400) ? -2 : dist;
}

// Matrix display
void displayPattern(const uint8_t *pattern) {
  for (uint8_t row = 0; row < 8; row++) {
    mx.setRow(0, row, pattern[row]);
  }
}

// Buzzer control (active buzzer version)
void beep(int onTime, int offTime, int count) {
  for (int i = 0; i < count; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(onTime);
    digitalWrite(BUZZER_PIN, LOW);
    if (i < count - 1) delay(offTime);
  }
}
