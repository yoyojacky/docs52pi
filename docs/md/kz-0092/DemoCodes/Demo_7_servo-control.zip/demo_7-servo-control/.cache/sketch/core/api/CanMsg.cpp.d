/home/arduino/ArduinoApps/demo_8_servo/.cache/sketch/core/api/CanMsg.cpp.o: \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/cores/arduino/api/CanMsg.cpp \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/generated/zephyr/autoconf.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/zephyr/toolchain/zephyr_stdint.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/cores/arduino/api/CanMsg.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/cores/arduino/api/Print.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/cores/arduino/api/String.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/cores/arduino/api/deprecated-avr-comp/avr/pgmspace.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/cores/arduino/api/Printable.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.0/cores/arduino/api/Common.h
