#include <Arduino.h>
#line 1 "/home/arduino/ArduinoApps/demo_8_servo/sketch/sketch.ino"
/*
 * Experiment 8: Servo Control (External Power Version)
 * Function: Servo sweeps 0°-180° back and forth
 * Hardware: EP-0257 Shield + SG90 + External 5V Power Supply
 * Library Dependency: Servo (built into Arduino)
 * 
 * ⚠️ IMPORTANT: Servo MUST be powered by external 5V supply, UNO Q only provides signal and common ground!
 */

#include <Servo.h>

Servo myServo;
#define SERVO_PIN 9

#line 15 "/home/arduino/ArduinoApps/demo_8_servo/sketch/sketch.ino"
void setup();
#line 27 "/home/arduino/ArduinoApps/demo_8_servo/sketch/sketch.ino"
void loop();
#line 15 "/home/arduino/ArduinoApps/demo_8_servo/sketch/sketch.ino"
void setup() {
  myServo.attach(SERVO_PIN);  // Bind to PWM pin D9
  
  Serial.begin(115200);
  Serial.println("Experiment 8: Servo Control");
  Serial.println("Ensure servo uses external 5V power supply!");
  
  // Initial position
  myServo.write(90);
  delay(500);
}

void loop() {
  Serial.println("0° -> 180°");
  for (int pos = 0; pos <= 180; pos += 2) {
    myServo.write(pos);
    delay(15);  // Wait for servo to reach position
  }
  
  delay(500);
  
  Serial.println("180° -> 0°");
  for (int pos = 180; pos >= 0; pos -= 2) {
    myServo.write(pos);
    delay(15);
  }
  
  delay(500);
}

