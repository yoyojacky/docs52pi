/*
 * Experiment 7: Servo Control 
 * Function: Servo sweeps 0°-180° back and forth
 * Hardware: EP-0257 Shield + SG90 
 * Library Dependency: Servo (built into Arduino)
 * 
 * 
 */

#include <Servo.h>

Servo myServo;
#define SERVO_PIN 9

void setup() {
  myServo.attach(SERVO_PIN);  // Bind to PWM pin D9
  
  Serial.begin(115200);
  Serial.println("Experiment 8: Servo Control");
  Serial.println("Ensure servo uses external 5V power supply!");
  
  // Initial position
  myServo.write(90);
  delay(500);
}

void loop() {
  Serial.println("0° -> 180°");
  for (int pos = 0; pos <= 180; pos += 2) {
    myServo.write(pos);
    delay(15);  // Wait for servo to reach position
  }
  
  delay(500);
  
  Serial.println("180° -> 0°");
  for (int pos = 180; pos >= 0; pos -= 2) {
    myServo.write(pos);
    delay(15);
  }
  
  delay(500);
}
