# 😀 Experiment 7: Servo Control

## Principle

The SG90 9g servo uses **PWM signal** to control angle, with a **20ms period** and **0.5ms–2.5ms pulse width** corresponding to **0°–180°**.
The SG90 9g servo is small and lightweight, drawing approximately **100mA typical current** and **up to 250mA at stall** — well within the UNO Q's onboard **5V regulator capacity** (~500mA via USB, ~1A via external DC jack). 

For a single SG90 9g servo, the onboard 5V pin is sufficient without requiring an external power supply.