# 😀 Experiment 1: GPIO LED + Buzzer

## Principle
* Digital GPIO outputs HIGH/LOW levels to control external modules. 
* Through the EP-0257, 3.3V signals are boosted to 5V, ensuring reliable recognition by 5V modules.

