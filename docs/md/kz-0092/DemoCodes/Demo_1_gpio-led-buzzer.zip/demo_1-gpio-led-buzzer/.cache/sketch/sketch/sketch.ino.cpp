#include <Arduino.h>
#line 1 "/home/arduino/ArduinoApps/demo1/sketch/sketch.ino"
#define BUZZER_PIN 2   
#define LED_PIN 3 

#line 4 "/home/arduino/ArduinoApps/demo1/sketch/sketch.ino"
void setup();
#line 11 "/home/arduino/ArduinoApps/demo1/sketch/sketch.ino"
void loop();
#line 4 "/home/arduino/ArduinoApps/demo1/sketch/sketch.ino"
void setup() {
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  Serial.begin(115200);
  Serial.println("Demo 1： GPIO output testing");
}

void loop() {
     digitalWrite(LED_PIN, HIGH);
     delay(500);
     digitalWrite(LED_PIN, LOW);
     delay(500);

     // buzzering 3 times 
    for(int i=0; i<3; i++){
      digitalWrite(BUZZER_PIN, HIGH);
      delay(200);
      digitalWrite(BUZZER_PIN, LOW);
      delay(200);
    }
  Serial.println("1 round test finished.");
  delay(1000);
}

