#include <Arduino.h>
#line 1 "/home/arduino/ArduinoApps/max72xx_display/sketch/sketch.ino"
/*
 * Experiment 3: SPI MAX7219 LED Matrix
 * Function: Display static patterns and dynamic scrolling effects
 * Hardware: EP-0257 Shield + MAX7219 8x8 Matrix
 * Library Dependency: MD_MAX72xx (install via Library Manager)
 */

#include <SPI.h>
#include <MD_MAX72xx.h>

#define HARDWARE_TYPE MD_MAX72XX::FC16_HW  // Module hardware type
#define MAX_DEVICES 1                      // Number of cascaded devices
#define CS_PIN 10                          // Chip select pin D10

MD_MAX72XX mx = MD_MAX72XX(HARDWARE_TYPE, CS_PIN, MAX_DEVICES);

// Define heart pattern (8x8 bitmap, 1=on, 0=off)
const uint8_t heart[8] = {
  0b00000000,
  0b01100110,
  0b11111111,
  0b11111111,
  0b01111110,
  0b00111100,
  0b00011000,
  0b00000000
};

#line 29 "/home/arduino/ArduinoApps/max72xx_display/sketch/sketch.ino"
void setup();
#line 40 "/home/arduino/ArduinoApps/max72xx_display/sketch/sketch.ino"
void loop();
#line 51 "/home/arduino/ArduinoApps/max72xx_display/sketch/sketch.ino"
void displayPattern(const uint8_t *pattern);
#line 66 "/home/arduino/ArduinoApps/max72xx_display/sketch/sketch.ino"
void animateHeart();
#line 29 "/home/arduino/ArduinoApps/max72xx_display/sketch/sketch.ino"
void setup() {
  mx.begin();           // Initialize MAX7219
  mx.control(MD_MAX72XX::INTENSITY, 8);  // Set brightness 0-15
  
  Serial.begin(115200);
  Serial.println("Experiment 3: MAX7219 LED Matrix");
  
  displayPattern(heart);
  delay(2000);
}

void loop() {
  // Scroll text display
  scrollText("HELLO UNO Q ");
  delay(1000);
  
  // Display animated pattern
  animateHeart();
  delay(1000);
}

// Display static bitmap
void displayPattern(const uint8_t *pattern) {
  for (uint8_t col = 0; col < 8; col++) {
    uint8_t colData = 0;
    // 从原始图案中提取这一列的数据
    for (uint8_t row = 0; row < 8; row++) {
      if (pattern[row] & (1 << (7 - col))) {
        colData |= (1 << row);
      }
    }
    mx.setColumn(0, col, colData);
  }
}
 

// Heart breathing light effect
void animateHeart() {
  for (int brightness = 0; brightness <= 15; brightness++) {
    mx.control(MD_MAX72XX::INTENSITY, brightness);
    displayPattern(heart);
    delay(80);
  }
  for (int brightness = 15; brightness >= 0; brightness--) {
    mx.control(MD_MAX72XX::INTENSITY, brightness);
    displayPattern(heart);
    delay(80);
  }
}

