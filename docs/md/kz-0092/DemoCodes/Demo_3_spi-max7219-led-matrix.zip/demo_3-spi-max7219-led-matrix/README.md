# 😀 Experiment 3: SPI MAX7219 8×8 LED Matrix

## Principle

SPI (Serial Peripheral Interface) is a four-wire full-duplex synchronous serial communication:
•	MOSI (Master Out Slave In): Master data output
•	MISO (Master In Slave Out): Master data input
•	SCK (Serial Clock): Clock signal
•	SS/CS (Slave Select): Chip select, active LOW

MAX7219 is a dedicated LED driver chip. It receives display data via SPI and automatically handles scan refresh; the MCU only needs to send data once to maintain display.





