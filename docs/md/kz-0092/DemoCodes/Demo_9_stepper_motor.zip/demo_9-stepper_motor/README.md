# 😀  Experiment 9: Stepper Motor


## Principle
The 28BYJ-48 stepper motor is a 4-phase 5-wire type. 
The ULN2003 driver board contains Darlington transistor arrays and can be directly driven by GPIO. 
Step angle 5.625°, gear ratio 1:64, actual step angle ~0.088°.


