# 😀 Experiment 4: HC-SR04 Ultrasonic Distance Measurement + Buzzer Alert


## Wiring Table

| Component | Pin | Arduino Pin | Notes |
|-----------|-----|-------------|-------|
| **HC-SR04** | VCC | 5V | Power supply |
| | GND | GND | Ground |
| | TRIG | D4 | Trigger output |
| | ECHO | D5 | Echo input (with 10kΩ pull-down if needed) |
| **Buzzer** | Signal (+) | D6 | PWM pin for `tone()` |
| | GND (-) | GND | Ground |
| | VCC | 5V | Active buzzer only |

## Pinout Diagram

```
    Arduino Uno                    HC-SR04 Ultrasonic Sensor
    +-----------+                +-----------+
    |           |                |   VCC     |-----> 5V
    |        5V |----------------|   GND     |-----> GND
    |       GND |----------------|   TRIG    |<<----- D4 (TRIG_PIN)
    |        D4 |--------------->|   ECHO    |-----> D5 (ECHO_PIN)
    |        D5 |<<--------------|           |
    |        D6 |--------------->|           |        Buzzer
    |           |                +-----------+> D6  +---------+ 
    +-----------+                                   |   +     |
                                                    |  Buzzer |
                                                    |   -     |
                                                    +----+----+
                                                         |
                                                         |
                                                    GND (GND)
                                                   
```

## Principle of Operation

### 1. Ultrasonic Distance Measurement

The HC-SR04 module measures distance using **time-of-flight** of ultrasonic waves:

| Step | Action | Timing |
|------|--------|--------|
| ① | Send a 10μs HIGH pulse to TRIG pin | Trigger signal |
| ② | Module emits 8 cycles of 40kHz ultrasound | ~200μs |
| ③ | Module waits for echo reflection | Variable |
| ④ | ECHO pin goes HIGH for duration = round-trip time | Measured by `pulseIn()` |

**Distance Formula:**

$$\text{Distance} = \frac{\text{Duration} \times \text{Speed of Sound}}{2} = \frac{\text{Duration} \times 343\,\text{m/s}}{2}$$

In microseconds:
$$\text{Distance (cm)} = \text{Duration (μs)} \times 0.01715$$

The division by 2 accounts for the **round-trip** distance (sound travels to the obstacle and back).

### 2. Proximity-Based Buzzer Alert

The buzzer response follows an **inverse relationship** with distance:

| Distance Zone | Behavior | Purpose |
|---------------|----------|---------|
| **<< 10 cm** | Beep every ~100ms, 2kHz, 300ms long | Urgent warning |
| **10–50 cm** | Beep every ~500ms, 1.2kHz, 200ms | Caution |
| **50–200 cm** | Beep every ~1500ms, 700Hz, 130ms | Awareness |
| **> 200 cm** | Silent | Safe zone |
| **Error** | Slow beep every 1s | Sensor fault |

**Key Design Principle:** The system uses **non-blocking `millis()` timing** instead of `delay()`, allowing:
- Continuous distance sampling (100ms intervals)
- Independent buzzer rhythm control
- No interference between measurement and alert timing

### 3. `map()` Function Behavior

The Arduino `map()` function linearly scales values:

```cpp
beepInterval = map(distance, 10, 200, 100, 2000);
// distance=10  -> 100ms  (fastest)
// distance=100 -> ~1058ms
// distance=200 -> 2000ms (slowest)
```

This creates an **intuitive auditory feedback**: the closer the obstacle, the more urgent the beeping sounds.
