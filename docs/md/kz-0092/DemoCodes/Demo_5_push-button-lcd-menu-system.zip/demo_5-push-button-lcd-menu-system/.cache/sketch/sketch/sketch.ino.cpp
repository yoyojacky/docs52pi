#include <Arduino.h>
#line 1 "/home/arduino/ArduinoApps/demo_5-push-button-lcd-menu-system/sketch/sketch.ino"
/*
 * Experiment 5: Push Button + LCD Menu System
 * Function: Three-layer menu navigation, control LED and buzzer
 * Hardware: EP-0257 Shield + LCD1602 + 3x Push Buttons
 * Library: Bonezegei_LCD1602_I2C
 */

#include <Bonezegei_LCD1602_I2C.h>

// create lcd object and default address is 0x27
Bonezegei_LCD1602_I2C lcd(0x27);

#define BTN_UP   6
#define BTN_DOWN 7
#define BTN_OK   8
#define LED_PIN  9
#define BUZZER   2

// Menu structure
const char* menuItems[] = {"LED Control", "Buzzer Test", "System Info"};
const int menuCount = 3;
int currentMenu = 0;
int menuLevel = 0;  // 0=Main menu, 1=Sub menu
bool ledState = false;

#line 26 "/home/arduino/ArduinoApps/demo_5-push-button-lcd-menu-system/sketch/sketch.ino"
void setup();
#line 43 "/home/arduino/ArduinoApps/demo_5-push-button-lcd-menu-system/sketch/sketch.ino"
void loop();
#line 48 "/home/arduino/ArduinoApps/demo_5-push-button-lcd-menu-system/sketch/sketch.ino"
void handleButtons();
#line 66 "/home/arduino/ArduinoApps/demo_5-push-button-lcd-menu-system/sketch/sketch.ino"
void showMainMenu();
#line 77 "/home/arduino/ArduinoApps/demo_5-push-button-lcd-menu-system/sketch/sketch.ino"
void executeMenu();
#line 26 "/home/arduino/ArduinoApps/demo_5-push-button-lcd-menu-system/sketch/sketch.ino"
void setup() {
  pinMode(BTN_UP, INPUT);
  pinMode(BTN_DOWN, INPUT);
  pinMode(BTN_OK, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  digitalWrite(BUZZER, LOW);
  
  // Bonezegei init 
  lcd.begin();
  
  Serial.begin(115200);
  Serial.println("Experiment 5: Button Menu System");
  
  showMainMenu();
}

void loop() {
  handleButtons();
  delay(150);  // Simple debounce
}

void handleButtons() {
  if (digitalRead(BTN_UP) == LOW) {
    if (menuLevel == 0) {
      currentMenu = (currentMenu - 1 + menuCount) % menuCount;
      showMainMenu();
    }
  }
  else if (digitalRead(BTN_DOWN) == LOW) {
    if (menuLevel == 0) {
      currentMenu = (currentMenu + 1) % menuCount;
      showMainMenu();
    }
  }
  else if (digitalRead(BTN_OK) == LOW) {
    executeMenu();
  }
}

void showMainMenu() {
  lcd.clear();
  // 使用 setPosition 替代 setCursor
  lcd.setPosition(0, 0);
  lcd.print("> ");
  lcd.print(menuItems[currentMenu]);
  lcd.setPosition(0, 1);
  lcd.print("  ");
  lcd.print(menuItems[(currentMenu + 1) % menuCount]);
}

void executeMenu() {
  lcd.clear();
  
  switch (currentMenu) {
    case 0: // LED Control
      ledState = !ledState;
      digitalWrite(LED_PIN, ledState ? HIGH : LOW);
      lcd.print("LED: ");
      lcd.print(ledState ? "ON " : "OFF");
      delay(1000);
      break;
      
    case 1: // Buzzer Test
      lcd.print("Buzzer Test...");
      for (int i = 0; i < 3; i++) {
        digitalWrite(BUZZER, LOW);
        delay(200);
        digitalWrite(BUZZER, HIGH);
        delay(200);
      }
      digitalWrite(BUZZER, LOW);
      break;
      
    case 2: // System Info
      lcd.print("UNO Q + EP-0257");
      // 使用 setPosition 替代 setCursor
      lcd.setPosition(0, 1);
      lcd.print("3.3V -> 5V OK");
      delay(2000);
      break;
  }
  
  showMainMenu();
}
