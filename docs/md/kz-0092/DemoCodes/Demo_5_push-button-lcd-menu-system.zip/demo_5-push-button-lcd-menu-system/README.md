# 😀  Experiment 5: Push Button + LCD Menu System

## Principle
Build a multi-layer menu interface navigated by push buttons. Use EP-0257's digital input function to safely read 5V button modules.

