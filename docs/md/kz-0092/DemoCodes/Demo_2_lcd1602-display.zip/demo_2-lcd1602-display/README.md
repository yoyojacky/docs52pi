# 😀  Experiment 2: I2C LCD1602 Display

## Principle

* I2C (Inter-Integrated Circuit) is a two-wire serial bus (SDA data + SCL clock). 
* UNO Q I2C pins are A4 (SDA) and A5 (SCL), which after EP-0257 conversion can directly drive 5V I2C devices.
* The LCD1602 I2C module integrates a PCF8574 expander chip, converting parallel interface to I2C, requiring only 4 wires for display control.





