#include <Arduino.h>
#line 1 "/home/arduino/ArduinoApps/demo_2-lcd1602-display/sketch/sketch.ino"
/*
 * Arduino UNO Q + EP-0257 + LCD1602 I2C - Kit Test
 * Bonezegei LCD1602 I2C v1.0.4 Corrected API
 */

#include <Bonezegei_LCD1602_I2C.h>

Bonezegei_LCD1602_I2C lcd(0x27);

#line 10 "/home/arduino/ArduinoApps/demo_2-lcd1602-display/sketch/sketch.ino"
void setup();
#line 27 "/home/arduino/ArduinoApps/demo_2-lcd1602-display/sketch/sketch.ino"
void loop();
#line 10 "/home/arduino/ArduinoApps/demo_2-lcd1602-display/sketch/sketch.ino"
void setup() {
  Serial.begin(115200);
  
  lcd.begin();
  lcd.setBacklight(1);  // Turn on backlight
  lcd.clear();
  
  // Welcome message
  lcd.setPosition(0, 0);
  lcd.print("UNO Q + EP-0257");
  lcd.setPosition(0, 1);
  lcd.print("Kit Ready!");
  
  Serial.println("LCD initialized with Bonezegei v1.0.4");
  delay(2000);
}

void loop() {
  static int count = 0;
  
  // Update second row with counter
  String msg = "Count: " + String(count) + "    ";
  lcd.setPosition(0, 1);
  lcd.print(msg.c_str());
  
  count++;
  delay(500);
}
