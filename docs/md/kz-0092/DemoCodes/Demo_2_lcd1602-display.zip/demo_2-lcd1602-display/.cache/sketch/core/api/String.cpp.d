/home/arduino/ArduinoApps/demo_2-lcd1602-display/.cache/sketch/core/api/String.cpp.o: \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/cores/arduino/api/String.cpp \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/generated/zephyr/autoconf.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/zephyr/toolchain/zephyr_stdint.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/cores/arduino/api/String.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/cores/arduino/api/deprecated-avr-comp/avr/pgmspace.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/cores/arduino/api/Common.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/cores/arduino/api/itoa.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/cores/arduino/api/deprecated-avr-comp/avr/dtostrf.h
