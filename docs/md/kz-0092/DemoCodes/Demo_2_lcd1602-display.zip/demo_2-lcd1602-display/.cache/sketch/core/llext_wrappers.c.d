/home/arduino/ArduinoApps/demo_2-lcd1602-display/.cache/sketch/core/llext_wrappers.c.o: \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/cores/arduino/llext_wrappers.c \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/generated/zephyr/autoconf.h \
 /home/arduino/.arduino15/packages/arduino/hardware/zephyr/0.55.2/variants/arduino_uno_q_stm32u585xx/llext-edk/include/zephyr/include/zephyr/toolchain/zephyr_stdint.h
