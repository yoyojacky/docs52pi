void setup() {
  pinMode(8, OUTPUT);   // Red LED
  pinMode(9, OUTPUT);   // Yellow LED
  pinMode(10, OUTPUT);  // Green LED
}

void loop() {
  // Green light
  digitalWrite(10, HIGH);
  delay(5000);  // 5 seconds
  digitalWrite(10, LOW);
  
  // Yellow light
  digitalWrite(9, HIGH);
  delay(2000);  // 2 seconds
  digitalWrite(9, LOW);
  
  // Red light
  digitalWrite(8, HIGH);
  delay(5000);  // 5 seconds
  digitalWrite(8, LOW);
}
