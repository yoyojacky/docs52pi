int redPin = 3;
int greenPin = 5;
int bluePin = 6;

void setup() {
  pinMode(redPin, OUTPUT);
  pinMode(greenPin, OUTPUT);
  pinMode(bluePin, OUTPUT);
}

void loop() {
  // Fade through colors
  for(int i = 0; i < 256; i++) {
    analogWrite(redPin, i);
    analogWrite(greenPin, 255-i);
    analogWrite(bluePin, i+5);
    delay(10);
  }
}
