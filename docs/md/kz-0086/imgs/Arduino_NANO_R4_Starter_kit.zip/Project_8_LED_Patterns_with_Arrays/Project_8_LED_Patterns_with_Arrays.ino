int ledPins[] = {2, 3, 4, 5, 6, 7, 8, 9};
int numLeds = 8;

void setup() {
  for(int i = 0; i < numLeds; i++) {
    pinMode(ledPins[i], OUTPUT);
  }
}

void loop() {
  // Knight Rider effect
  for(int i = 0; i < numLeds; i++) {
    digitalWrite(ledPins[i], HIGH);
    delay(100);
    digitalWrite(ledPins[i], LOW);
  }
  for(int i = numLeds - 2; i > 0; i--) {
    digitalWrite(ledPins[i], HIGH);
    delay(100);
    digitalWrite(ledPins[i], LOW);
  }
  
  // Random twinkle
  for(int i = 0; i < 20; i++) {
    int randomLed = random(numLeds);
    digitalWrite(ledPins[randomLed], HIGH);
    delay(50);
    digitalWrite(ledPins[randomLed], LOW);
  }
}
